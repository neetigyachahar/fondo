var contentTabId;
if(getCookie('active').length == 0){
  setCookie('active', 1, 730);
}
chrome.runtime.onMessage.addListener(function(msg,sender) {

  if (msg.from == "content") {  //get content scripts tab id
    contentTabId = sender.tab.id;
    console.log(contentTabId);

    var views = chrome.extension.getViews({
      type: "popup"
    });
    console.log(views);
    for (var i = 0; i < views.length; i++) {
      views[i].document.getElementById('body').innerHTML = "My Custom Value";
  }
    var ID;
    const xhttp = new XMLHttpRequest();

    function getCookies(domain, name) 
    {
        chrome.cookies.get({"url": domain, "name": name}, function(cookie) {
            ID = cookie.value;
            inject();
        });
    }

    function inject() {
        console.log(ID);
        xhttp.onreadystatechange = function (){
          if(this.readyState == 4 && this.status == 200){
            var data = JSON.parse(this.responseText);
            // views[0].document.getElementById('body').innerHTML = "My Custom Value";
            chrome.tabs.sendMessage(contentTabId, {  //send it to content script
              from: "background",
              first: getCookie('active'),
              second: data.html,
              third: data.link
            });
          }
        };

      xhttp.open('get', `http://www.fondo.xyz/extend?id=${ID}`, true);
      xhttp.send();
      
      // var data = {
      //   html: "nill",
      //   link: "#"
      // };
      // chrome.tabs.sendMessage(contentTabId, {  //send it to content script
      //   from: "background",
      //   first: getCookie('active'),
      //   second: data.html,
      //   third: data.link
      // });
    }   

    getCookies("http://www.fondo.xyz", "ProfileID");     

}
});

function setCookie(cname, cvalue, exdays) {
  var d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  var expires = "expires="+d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for(var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}  